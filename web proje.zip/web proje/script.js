// Sayfa yüklendiğinde çalışır
document.addEventListener("DOMContentLoaded", function () {
    console.log("script.js aktif");

    const buttons = document.querySelectorAll("button");

    buttons.forEach(btn => {
        btn.addEventListener("click", function () {
            alert("Butona tıklandı (JavaScript çalışıyor)");
        });
    });
});

